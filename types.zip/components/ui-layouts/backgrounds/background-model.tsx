// @ts-nocheck
'use client';

import { useEffect, useRef, useState } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { useFBO, useTexture } from '@react-three/drei';
import * as THREE from 'three';
import useMouse from './use-mouse';
import useDimension from './use-dimension';
import { vertex, fragment } from './background-shaders';

export default function BackgroundModel() {
  const { viewport } = useThree();
  const texture = useTexture('/brush.png');
  const meshRefs = useRef<any[]>([]);
  const [meshes, setMeshes] = useState<any[]>([]);
  const mouse = useMouse();
  const device = useDimension();
  const [prevMouse, setPrevMouse] = useState({ x: 0, y: 0 });
  const [currentWave, setCurrentWave] = useState(0);
  const { camera } = useThree();

  const scene = new THREE.Scene();
  const max = 100;

  const uniforms = useRef({
    uDisplacement: { value: null },
    uTexture: { value: null },
    winResolution: { value: new THREE.Vector2(0, 0) },
  });

  const fboBase = useFBO(device.width, device.height);
  const fboTexture = useFBO(device.width, device.height);

  const { scene: imageScene, camera: imageCamera } = Images(viewport);

  useEffect(() => {
    const generatedMeshes = Array.from({ length: max }).map((_, i) => (
      <mesh
        key={i}
        position={[0, 0, 0]}
        ref={(el) => (meshRefs.current[i] = el)}
        rotation={[0, 0, Math.random()]}
        visible={false}
      >
        <planeGeometry args={[60, 60, 1, 1]} />
        <meshBasicMaterial transparent map={texture} />
      </mesh>
    ));
    setMeshes(generatedMeshes);
  }, [texture]);

  function setNewWave(x: number, y: number, waveIndex: number) {
    const mesh = meshRefs.current[waveIndex];
    if (mesh) {
      mesh.position.x = x;
      mesh.position.y = y;
      mesh.visible = true;
      mesh.material.opacity = 1;
      mesh.scale.x = 1.75;
      mesh.scale.y = 1.75;
    }
  }

  function trackMousePos(x: number, y: number) {
    if (Math.abs(x - prevMouse.x) > 0.1 || Math.abs(y - prevMouse.y) > 0.1) {
      setCurrentWave((value) => (value + 1) % max);
      setNewWave(x, y, currentWave);
    }
    setPrevMouse({ x, y });
  }

  useFrame(({ gl, scene: finalScene }) => {
    const x = mouse.x - device.width / 2;
    const y = -mouse.y + device.height / 2;
    trackMousePos(x, y);
    meshRefs.current.forEach((mesh) => {
      if (mesh.visible) {
        mesh.rotation.z += 0.025;
        mesh.material.opacity *= 0.95;
        mesh.scale.x = 0.98 * mesh.scale.x + 0.155;
        mesh.scale.y = 0.98 * mesh.scale.y + 0.155;
      }
    });

    if (device.width > 0 && device.height > 0) {
      gl.setRenderTarget(fboBase);
      gl.clear();
      meshRefs.current.forEach((mesh) => {
        if (mesh.visible) {
          scene.add(mesh);
        }
      });
      gl.render(scene, camera);
      meshRefs.current.forEach((mesh) => {
        if (mesh.visible) {
          scene.remove(mesh);
        }
      });
      uniforms.current.uTexture.value = fboTexture.texture;

      gl.setRenderTarget(fboTexture);
      gl.render(imageScene, imageCamera);
      uniforms.current.uDisplacement.value = fboBase.texture;

      gl.setRenderTarget(null);
      gl.render(finalScene, camera);

      uniforms.current.winResolution.value = new THREE.Vector2(device.width, device.height).multiplyScalar(device.pixelRatio);
    }
  }, 1);

  function Images(viewport: { width: number; height: number }) {
    const scene = new THREE.Scene();
    const camera = new THREE.OrthographicCamera(
      viewport.width / -2,
      viewport.width / 2,
      viewport.height / 2,
      viewport.height / -2,
      -1000,
      1000,
    );
    camera.position.z = 2;
    scene.add(camera);
    const geometry = new THREE.PlaneGeometry(1, 1);
    const group = new THREE.Group();
    const texture1 = useTexture('/picture1.jpeg');
    const material1 = new THREE.MeshBasicMaterial({ map: texture1 });
    const image1 = new THREE.Mesh(geometry, material1);
    image1.position.x = -0.25 * viewport.width;
    image1.position.y = 0;
    image1.position.z = 1;
    image1.scale.x = viewport.width / 5;
    image1.scale.y = viewport.width / 4;
    group.add(image1);

    const texture2 = useTexture('/picture2.jpeg');
    const material2 = new THREE.MeshBasicMaterial({ map: texture2 });
    const image2 = new THREE.Mesh(geometry, material2);
    image2.position.x = 0;
    image2.position.y = 0;
    image2.position.z = 1;
    image2.scale.x = viewport.width / 5;
    image2.scale.y = viewport.width / 4;
    group.add(image2);

    const texture3 = useTexture('/picture3.jpeg');
    const material3 = new THREE.MeshBasicMaterial({ map: texture3 });
    const image3 = new THREE.Mesh(geometry, material3);
    image3.position.x = 0.25 * viewport.width;
    image3.position.y = 0;
    image3.position.z = 1;
    image3.scale.x = viewport.width / 5;
    image3.scale.y = viewport.width / 4;
    group.add(image3);

    scene.add(group);
    return { scene, camera };
  }

  return (
    <group>
      {meshes}
      <mesh>
        <planeGeometry args={[device.width, device.height, 1, 1]} />
        <shaderMaterial vertexShader={vertex} fragmentShader={fragment} transparent uniforms={uniforms.current} />
      </mesh>
    </group>
  );
}
